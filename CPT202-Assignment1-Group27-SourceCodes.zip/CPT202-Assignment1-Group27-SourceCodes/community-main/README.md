## CPT202 Group Project
A web app help SAT students especially for CS major to find internships or even work.

## Records of framework we use
### frontend
Thymeleaf:
https://www.thymeleaf.org/doc/articles/layouts.html

Bootstrap:
https://v3.bootcss.com/getting-started/

### backend

OAuth App
https://docs.github.com/en/developers/apps/creating-an-oauth-app

Spring Boot
https://docs.spring.io/spring-boot/docs/current/reference/htmlsingle/

MyBatis
https://mybatis.org/mybatis-3/index.html

H2: lightweight database
http://www.h2database.com/html/main.html

Flyway: database migrate
https://flywaydb.org/getstarted/firststeps/maven

Lombok
https://www.projectlombok.org/setup/maven

## Run this project in your device

1. Download the zip file
2. Unzip and open use **IntelliJ IDEA Ultimate**
3. Download and Configure Maven
   1. enter <u>mvn --version</u> to test successfulness
4. Enter: <u>mvn flyway:migrate</u> in **IDEA's Terminal**
   1. only do this for the first time
5. Run this project in IDEA
6. Open the browser and enter：<u>localhost:8080</u>
7. You should see our project
   1. but its does not contain any data since we use local database and you migrate the database, later when we deploy our project to the cloud, we will have a certain database to store our data.

